## 추가 원본과 수업에서 만든 기준 구분

- USER 교차 대조: [Google Gemini CLI 컨텍스트 범위](https://github.com/google-gemini/gemini-cli/blob/93844dfa10f6d71edc09be40dfde205edfbcc939/docs/cli/gemini-md.md#L18-L35)는 계정 전반의 기본값과 현재 작업공간의 맥락을 분리한다. ‘이 업무의 산출물을 고를 수 있는가’는 Google의 공식 USER 규칙이 아니라 수업에서 만든 시험이다.
- AGENTS 교차 대조: [OpenAI Codex 저장소 실제 지침](https://github.com/openai/codex/blob/4875084025582f9443afeb907e2aa20644241dda/AGENTS.md#L180-L198)은 UI 변경의 결과물을 생성하고 차이를 직접 검토하게 한다. ‘준비/발송 경계와 완료의 증거’는 그 검증 방식에 대조한 수업용 규칙이다. 외부 저장소의 코드 작업 명령을 수강생에게 적용하지 않는다.

## 현행판: 질문 네 가지 + 작성·검수 네 가지

기존 네 인터뷰에 문서별 작성 스킬을 연결했다. 공개 스킬을 찾아 원칙을 검토했고, 외부 실행 파일을 들여오지 않고 수업용으로 새로 썼다. 공식 템플릿은 참고자료이지 실행 스킬이 아니다.

- USER: [OpenClaw User Profiler](https://github.com/eamanc-lab/openclaw-persona-forge/blob/main/skills/openclaw-user-profiler/SKILL.md) · [보조 문서](https://docs.openclaw.ai/reference/templates/USER). 확인한 맥락을 초안으로 보여주는 방식을 참고했다. 개인정보 필드와 추가 인터뷰는 제외한다.
- SOUL: [SoulCraft](https://github.com/kesslerio/soulcraft-openclaw-skill/blob/main/SKILL.md) · [보조 문서](https://docs.openclaw.ai/reference/templates/SOUL). 추상적인 어조를 실제 상황의 표현으로 시험한다. 행동 권한은 이 수업에서 AGENTS 담당이다.
- AGENTS: [agents-md](https://github.com/akunzai/agent-skills/blob/4a5f846a4a0af2d987d6f332df56026419610f4e/skills/agents-md/SKILL.md) · [보조 문서](https://agents.md/). 짧은 기준 하나를 원본으로 유지한다. 장황한 매뉴얼과 중복 지침을 만들지 않는다.
- MEMORY: [agents-memory](https://github.com/akunzai/agent-skills/blob/4a5f846a4a0af2d987d6f332df56026419610f4e/skills/agents-memory/SKILL.md) · [보조 문서](https://docs.openclaw.ai/concepts/memory). 검증되고 재사용 가능하며 안정적인 정보만 남긴다. 전역 메모리나 로그 생성은 제외한다.

> 후속 개정: 아래는 초기 제작 이력이다. 현재판은 다음 판단을 바꾸지 않는 질문에서 먼저 멈추며, 저장 후 같은 수업 폴더에서 사용자가 명시한 지속 변경은 해당 문서에 자동 반영한다. 아래 초기 해시는 현행판 해시가 아니다.

# 수업용 인터뷰 스킬 4종: 출처와 검증

## 공개 원문: 단일 질문형과 현재형은 다르다

2026-11-20 확인. 원저장소는 [Matt Pocock의 mattpocock/skills](https://github.com/mattpocock/skills)다. 아래 링크는 모두 브랜치가 아닌 전체 커밋으로 고정했다.

| 직접 확인한 소스 | 원문이 실제로 하는 일 | 이 수업에 반영한 점 |
|---|---|---|
| [단일 질문형 grill-me/SKILL.md](https://github.com/mattpocock/skills/blob/62f43a18177be6ec82da242e59ffbc490a4c22ea/skills/productivity/grill-me/SKILL.md), `62f43a18177be6ec82da242e59ffbc490a4c22ea` | 한 번에 질문 하나, 앞의 결정에 따라 갈림길을 따라가기. 질문별 추천 답, 코드에서 확인 가능한 사실은 직접 탐색하기도 제안한다. | 한 번에 한 질문과 종속된 후속 질문을 채택했다. 추천 답을 학생 사실로 쓰거나 코드베이스 전체를 탐색하지 않는다. |
| [현재 grill-me 진입점](https://github.com/mattpocock/skills/blob/abeeaf95660ba9e8b7c753eb38f441ca707a8823/skills/productivity/grill-me/SKILL.md), [실제 grilling 본문](https://github.com/mattpocock/skills/blob/abeeaf95660ba9e8b7c753eb38f441ca707a8823/skills/productivity/grilling/SKILL.md), `abeeaf95660ba9e8b7c753eb38f441ca707a8823` | 진입점은 grilling 호출만 한다. 실제 본문은 선행 결정이 끝난 질문들을 여러 개 모아 한 라운드에 묻고 다음 라운드의 갈림길을 갱신한다. | 답에 따라 다시 판단하는 원리는 참고했다. 여러 질문 묶기·일괄 추천·환경 조사 위임은 채택하지 않았다. |

네 파일은 원문 번역이나 복제가 아니다. 학생용 질문·반례·동의 절차·개인정보 분기·파일 검증은 한국어 수업과 기존 네 스킬 기준으로 다시 썼다. 공개 원본의 자동 설치·호출은 필요 없다. [단일 질문판 라이선스](https://github.com/mattpocock/skills/blob/62f43a18177be6ec82da242e59ffbc490a4c22ea/LICENSE)와 [현재판 라이선스](https://github.com/mattpocock/skills/blob/abeeaf95660ba9e8b7c753eb38f441ca707a8823/LICENSE)는 같은 MIT 문구다. upstream 권리 표시는 아래 보존했다. 원문/상당 부분을 따로 재배포한다면 저작권·허가문을 함께 유지해야 한다. 이 고지는 교재나 다른 제작물의 재배포 허가를 의미하지 않는다.

## 교재와 기존 수업 스킬

기준은 중급반 1회차 인쇄 교재(117쪽, PDF SHA-256 `95b0a87e6fee801a2eea07687a9efa421a1eccb4d088bec1605d9ca6142fbc58`)와 기존 계정의 `class-grill-{user,soul,agents,memory}/SKILL.md` 네 파일이다. 교육용 역할·존댓말·건너뛰기는 유지하고, ‘채팅에서 Markdown만 주고 학생이 직접 저장’하던 규칙은 수업 루트 한 파일 안에서 실제 초안을 만드는 선택지로 바꿨다.

| 명시 호출 | 교재 | 예시 답이 바꾸는 다음 질문 | 담당 파일 |
|---|---|---|---|
| `/class-grill-user` | 85~90쪽 | 직함만 말하면 실제 업무, 결과물까지 말하면 성공 기준 | `./USER.md` |
| `/class-grill-soul` | 91~96쪽 | ‘친절하게’면 같은 내용의 두 표현, ‘한 줄인데 자세히’면 예외 상황 | `./SOUL.md` |
| `/class-grill-agents` | 97~102쪽 | 실제 전송 전 멈춘다면 초안 허용 경계, 경계가 분명하면 완료 근거 | `./AGENTS.md` |
| `/class-grill-memory` | 103~106쪽 | 이번 행사면 적용 범위, 다른 마감이 등장하면 기존 결정 변경인지 별개인지 | `./MEMORY.md` |

107~108쪽의 역할 구분, 110~115쪽의 하루 한 문서·사실 대조·실제 파일 재열람을 함께 반영했다. 폴더가 수업 루트인지 확인한 뒤 Claude Code에서 해당 슬래시 명령 하나만 실행한다. 동의 전에는 쓰지 않으며 거절하면 채팅 미리보기만 제공한다. 동의한 뒤 같은 문서의 확인된 새 줄을 적는 일은 매번 재승인받지 않는다. 이미 있던 내용을 바꾸거나 지우는 일에는 구체적인 변경안 승인이 별도로 필요하다. 저장했다고 다른 세션이 자동 참조한다고 설명하지 않는다.

## 제작 검증과 범위

- **형식:** 내장 skill-creator의 `scripts/validate-frontmatter.mjs`를 사용했다. 이름과 디렉터리 대응, 실행 트리거, 루트 한 파일 경계, 동의 분기, 재열람 지시를 실제 파일에서 확인했다.
- **시나리오 대조(문서 검토):** 신규/기존/거절·보류 → 해당 질문 하나 후 대기. 기존 합의와 충돌 → 전후안 표시·승인 전 유지. 민감 값 → 다시 인용하지 않고 역할로 재질문. 예시·무응답·건너뜀 → 값 미생성. 경로 이탈·링크·외부 변경 → 쓰기 중단. 저장 근거 없음 → 미확인. 실명·연락처 입력이나 실제 발송 없이 대조했다.
- **동기화와 복원:** 기존 계정본은 활성 스킬 검색 위치 밖, Aside 계정 루트의 `skills-backups/2026-11-20_official-class-v2_before_sync/class-grill-*/SKILL.md.original`에 분리 백업해 바이트를 대조한 뒤 같은 이름 네 개만 동기화했다. 되돌릴 때는 담당 백업만 해당 계정 스킬 폴더의 `SKILL.md`로 복원한다. 학생 배포본에는 이 계정 백업을 넣을 필요가 없다. 수업용 명시 호출과 실제 프로젝트 내 스킬 경로를 요구하며 일반 요청에는 적용하지 않는다. 계정의 실제 사용자 문서나 메모리는 바꾸지 않았다.
- **한계:** 프런트매터 통과는 Claude Code에서의 모델 동작 보장이 아니다. 이 제작 검사는 학생 계정 로그인·실제 수업 세션 종단 테스트·모든 실행 경로의 강제 차단을 증명하지 않는다. 파일 도구의 실제 승인 설정은 학생 환경에 따른다.

| 스킬 | 백업 SHA-256 | 학생용 = 동기화본 SHA-256 |
|---|---|---|
| class-grill-user | `70a580b2f5667e8601bbb1b10146fecce49edb778ae81b8e1e75b24b3bf952bd` | `bd3031e7720ed6c2b04b119d9b0fa7434b5ce740e3313b320a4121dbae41b152` |
| class-grill-soul | `e11e08c8a1b6d8d0dc14844d546f68f7aabf028b3af088fd81f2784e67b549a1` | `fcdb128976f216f4dcaee1791377c80f894a79d6794b84f7705b1d3421673fb9` |
| class-grill-agents | `8f58f04d94902b651fb7383c521482f25eed2172fdd92e2e7a173ce7c7db9c63` | `6430720600a05cb620310fe9d05bd4744870999078d1c7be0849d23a4c27b1db` |
| class-grill-memory | `4e320ca48409ed574315f5b0d9648b45dd47cad59bc9b37ef982ace6e4c632c2` | `b9ee65c24c48790047cd479aa0d4606d33489563bb153ba80ba50982bb001919` |

## 공개 원본 라이선스 고지

```text
MIT License

Copyright (c) 2026 Matt Pocock

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
