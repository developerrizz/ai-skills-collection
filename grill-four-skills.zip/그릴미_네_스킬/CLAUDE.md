# 수업용 문서 관리
이 workspace에서만 적용한다. 외부 프로젝트나 계정 전역 규칙을 고치지 않는다. 저장된 학생 문서에 관해 본인이 앞으로도 적용할 방향을 직접 밝히면 슬래시 명령 없이 해당 스킬을 읽고 ‘이후 갱신’을 따른다. 일회성 요청·예시·추측·인용·저장 거절은 기록하지 않는다.

- 하는 일·목표·결과물: USER.md → class-grill-user
- 말투·구성·설명 방식: SOUL.md → class-grill-soul
- 행동·권한·검수 절차: AGENTS.md → class-grill-agents
- 계속 쓸 사실·결정: MEMORY.md → class-grill-memory

스킬 원문은 .claude/skills/<이름>/SKILL.md다. 문서 하나에 한 번만 기록하고 본래 요청을 이어간다. 인터뷰에서는 답으로 다음 행동이 달라지지 않으면 먼저 멈춘다.
